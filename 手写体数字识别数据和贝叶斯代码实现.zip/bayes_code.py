import numpy as npy
import os
#P(B|A)=P(A|B)*P(A)/P(B)
class Bayes:
    def __init__(self):
        self.length=-1
        self.labelrate=dict()
        self.vectorrate=dict()
    def fit(self,dataset:list,labels:list):
        if len(dataset)!=len(labels):
            raise ValueError("输入测试数组和类别数组长度不一致")
        self.length=len(dataset[0])#训练数据特征值的长度
        labelsnum=len(labels) #类别的数量
        norlabels=set(labels) #不重复类别的数量
        for item in norlabels:
            self.labelrate[item]=labels.count(item)/labelsnum #求当前类别占总类别的比例
        for vector,label in zip(dataset,labels):
            if label not in self.vectorrate:
                self.vectorrate[label]=[]
            self.vectorrate[label].append(vector)
        print("训练结束")
        return self
    def btest(self,testdata,labelset):
        if self.length==-1:
            raise ValueError("未开始训练，先训练")
        #计算testdata分别为各个类别的概率
        lbDict=dict()
        for thislb in labelset:
            p = 1
            alllabel = self.labelrate[thislb]
            allvector = self.vectorrate[thislb]
            vnum=len(allvector)
            allvector=npy.array(allvector).T
            for index in range(0,len(testdata)):
                vector=list(allvector[index])
                p*=vector.count(testdata[index])/vnum
            lbDict[thislb]=p * alllabel
        thislbabel=sorted(lbDict,key=lambda x:lbDict[x],reverse=True)[0]
        return thislbabel
#加载数据
def datatoarray(fname):
    arr=[]
    fh=open(fname)
    for i in range(0,32):
        thisline=fh.readline()
        for j in range(0 , 32):
            arr.append(int(thisline[j]))
    return arr
#建立一个函数取出labels
def seplabel(fname):
    filestr=fname.split(".")[0]
    label=int(filestr.split("_")[0])
    return label
#建立训练数据
def traindata():
    labels=[]
    trainfile=os.listdir("./traindata")
    num=len(trainfile)
    trainarr=npy.zeros((num,1024))
    for i in range(num):
        thisfname=trainfile[i]
        thislabel=seplabel(thisfname)
        labels.append(thislabel)
        trainarr[i,]=datatoarray("./traindata/"+thisfname)
    return trainarr,labels
bys=Bayes()
#训练数据
train_data,labels=traindata()
train_data=list(train_data)
bys.fit(train_data,labels)

#测试
thisdata=datatoarray("./testdata/8_90.txt")
labelsall=[0,1,2,3,4,5,6,7,8,9]

#识别单个手写体数字
# test=bys.btest(thisdata,labelsall)
# print(test)

#识别多个手写体数字（批量处理）
testfile=os.listdir("./testdata")
num=len(testfile)
x=0
for i in range(num):
    thisfilename=testfile[i]
    thislabel=seplabel(thisfilename)
    thisdataarr=datatoarray("./testdata/"+thisfilename)
    label=bys.btest(thisdataarr,labelsall)
    print("测试数字是："+str(thislabel)+"识别出来的数字是："+str(label))
    if label!=thislabel:
        x+=1
        print("识别出错")
print(x)
print("出错率："+str(x/num))
